 <footer>
    <div class="container">
		<p>Copyright &copy; <?php echo date("Y"); ?> Ace in the Hole Multisport Events<br>
        <a href="mailto:contact@aceinthehole.com">contact@aceinthehole.com</a></p>
    </div>
		 
    <div class="container">
      <ul>
        <li><a href="<?php echo BASE_URL; ?>">Home</a></li>
        <li><a href="<?php echo BASE_URL; ?>events">Events</a></li>
        <li><a href="<?php echo BASE_URL; ?>faq">FAQ</a></li>
        <li><a href="<?php echo BASE_URL; ?>register">Register</a></li>
		<li><a href="<?php echo BASE_URL; ?>contact">Contact</a></li>
      </ul>
    </div>
		 
    <div class="container">
        <a href="https://www.facebook.com/cas222cascade/" class="fa fa-facebook"></a>
        <a href="https://twitter.com/pcccas222?ref_src=twsrc%5Etfw" class="fa fa-twitter"></a>
    </div>
</footer>