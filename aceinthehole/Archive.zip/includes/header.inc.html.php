<?php define("BASE_URL", "/cas222/aceinthehole/"); ?> 

<header>
	<img src="<?php echo BASE_URL; ?>images/ace_logo.png" alt="Ace Logo" id="aceLogo">
    
        <?php include 'nav.inc.html.php'; ?>
    
</header>
